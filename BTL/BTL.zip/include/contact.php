<?php
if(isset($_POST['submit'])){	
	$name = $_POST['name'];	
	$email = $_POST['email'];	
	$subject = $_POST['subject'];	
	$message = $_POST['message'];
	$pn = 'n/a';
	$body = 'Name: ' . $name . "\n\n" . 'Email: ' . $email . "\n\n" . 'Subject: ' . $subject . "\n\n" . 'Message: ' . $message . "\n\n" . 'Phone Number:' . $pn;	
	$sent_email = "truongthanhtu1613@gmail.com";
	if(mail($sent_email, $subject, $body, "From: $email")){	 
		$info = "The Mail Was Sent Successfully !";	 
	}else{
		$info = "The Mail Failed To Be Sent Successfully !";
	}
}
?>
<div class="w3-container w3-content w3-padding-64" style="max-width:800px" id="contact">
    <h2 class="w3-wide w3-center">CONTACT</h2>
    <p class="w3-opacity w3-center"><i>Contact me here!</i></p>
    <div class="w3-row w3-padding-32">
      <div class="w3-col m6 w3-large w3-margin-bottom ">
        <i class="fa fa-map-marker" style="width:30px"></i> Ha Noi, Viet Nam<br>
        <i class="fa fa-phone" style="width:30px"></i> Phone: +84 09763 67675<br>
        <i class="fa fa-envelope" style="width:30px"> </i> Email: truongthanhtu1613@gmail.com<br>
      </div>
      <div class="w3-col m6">
        <form action="" method="post">
		<p style="color:#f00;text-align:center;"><?php if(!empty($info)){ echo $info; }?></p>
          <div class="w3-row-padding" style="margin:0 -16px 8px -16px">
            
        </form>
      </div>
    </div>
  </div>