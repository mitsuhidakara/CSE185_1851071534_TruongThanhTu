<?php if(empty($_GET['user_id'])){ ?>
<title>Curriculum Vitae Maker</title>
<?php } ?>