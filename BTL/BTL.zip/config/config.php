<?php
	session_start();
	$mysqli = new mysqli("localhost","root","","btl");
?>